import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
import numpy as np

# Parse the XML
#tree = ET.parse('0200_0300_v2x_InTAS.simulation.tripinfo.xml')
#tree = ET.parse('0600_0830_v2x_InTAS.simulation.tripinfo.xml')
tree = ET.parse('1430_1800_v2x_InTAS.simulation.tripinfo.xml')
root = tree.getroot()

vehicle_ids = []
waiting_time = []
time_loss = []

# Iterate through each 'tripinfo' element
for tripinfo in root.findall('.//tripinfo'):
    vehicle_ids.append(tripinfo.attrib['id'])
    waiting_time.append(float(tripinfo.attrib['waitingTime']))
    time_loss.append(float(tripinfo.attrib['timeLoss']))

# Create a figure
fig, ax = plt.subplots(figsize=(6, 3))

# Define the width of the bars
bar_width = 0.2

# Create an array to position the bars side by side
index = np.arange(len(vehicle_ids))

# Plot waiting time
bar1 = plt.bar(index, waiting_time, bar_width, color='blue', label='Waiting Time')

# Plot time loss next to waiting time
bar2 = plt.bar(index + bar_width, time_loss, bar_width, color='red', label='Time Loss')

# Add values on top of the bars
for i, val in enumerate(waiting_time):
    plt.text(i, val + 2, str(val), ha='center', va='bottom', color='blue')

for i, val in enumerate(time_loss):
    plt.text(i + bar_width, val + 2, str(val), ha='center', va='bottom', color='red')

# Labeling and customization
plt.xlabel('Vehicle ID')
plt.ylabel('Time')
plt.title('Waiting Time and Time Loss per EMVs- Using V2X',fontsize=14)
plt.xticks(index + bar_width/2, vehicle_ids, rotation='vertical')
plt.ylim(0, 100)
plt.legend(loc='upper left', bbox_to_anchor=(1, 1))

# Show the plot
plt.tight_layout()
plt.show()
